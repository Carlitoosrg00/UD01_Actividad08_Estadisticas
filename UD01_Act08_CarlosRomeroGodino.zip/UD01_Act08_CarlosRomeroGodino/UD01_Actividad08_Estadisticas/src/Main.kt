// Importa la función sqrt para calcular raíces cuadradas
import kotlin.math.sqrt
import kotlin.random.Random

// Función principal del programa
fun main() {

    // Lista mutable donde se almacenarán los 100 números
    var numeros = mutableListOf<Int>()

    // Variable para guardar la opción seleccionada en el menú
    var opcion: Int

    // Bucle principal del programa
    // Se repetirá hasta que el usuario elija la opción 8
    do {

        // Mostrar menú por pantalla
        println("\n===== ESTADÍSTICAS CON KOTLIN =====")
        println("1. Generar 100 números aleatorios")
        println("2. Introducir 100 números manualmente")
        println("3. Mostrar números")
        println("4. Calcular media")
        println("5. Calcular moda")
        println("6. Calcular desviación típica")
        println("7. Calcular todas las estadísticas")
        println("0. Salir")

        // Solicitar una opción al usuario
        print("Seleccione una opción: ")

        // Leer la opción y convertirla a entero
        // Si no es válida se asigna -1
        opcion = readlnOrNull()?.toIntOrNull() ?: -1

        // Evaluar la opción elegida
        when (opcion) {

            // Opción 1: generar números aleatorios
            1 -> {

                // Vacía la lista por si ya tenía datos
                numeros.clear()

                // Repite el código 100 veces
                repeat(100) {

                    // Genera un número aleatorio entre 1 y 100
                    numeros.add(Random.nextInt(1, 101))
                }

                // Mensaje de confirmación
                println("Se han generado 100 números aleatorios.")
            }

            // Opción 2: introducir números manualmente
            2 -> {

                // Borra los datos anteriores
                numeros.clear()

                // Mensaje para el usuario
                println("Introduce 100 números:")

                // Mientras haya menos de 100 números
                while (numeros.size < 100) {

                    // Mostrar qué número se está solicitando
                    print("Número ${numeros.size + 1}: ")

                    // Leer el número introducido
                    val numero = readlnOrNull()?.toIntOrNull()

                    // Si es válido
                    if (numero != null) {

                        // Se almacena en la lista
                        numeros.add(numero)

                    } else {

                        // Mensaje de error
                        println("Debe introducir un número válido.")
                    }
                }

                // Confirmación de que se han guardado los datos
                println("Se han almacenado los 100 números.")
            }

            // Opción 3: mostrar números
            3 -> {

                // Comprobar si la lista está vacía
                if (numeros.isEmpty()) {

                    println("La lista está vacía.")

                } else {

                    // Llamar a la función que muestra los números
                    mostrarNumeros(numeros)
                }
            }

            // Opción 4: calcular media
            4 -> {

                // Verificar que existan datos
                if (numeros.isEmpty()) {

                    println("No hay datos para calcular la media.")

                } else {

                    // Mostrar la media calculada
                    println("Media: ${calcularMedia(numeros)}")
                }
            }

            // Opción 5: calcular moda
            5 -> {

                // Verificar que existan datos
                if (numeros.isEmpty()) {

                    println("No hay datos para calcular la moda.")

                } else {

                    // Guardar la moda o modas encontradas
                    val modas = calcularModa(numeros)

                    // Si no existe moda
                    if (modas.isEmpty()) {

                        println("No existe moda. Todos los números aparecen una sola vez.")

                        // Si existe una única moda
                    } else if (modas.size == 1) {

                        println("La moda es: ${modas[0]}")

                        // Si existen varias modas
                    } else {

                        println("Las modas son: ${modas.joinToString(", ")}")
                    }
                }
            }

            // Opción 6: calcular desviación típica
            6 -> {

                // Comprobar que haya datos
                if (numeros.isEmpty()) {

                    println("No hay datos para calcular la desviación típica.")

                } else {

                    // Mostrar resultado
                    println("Desviación típica: ${calcularDesviacionTipica(numeros)}")
                }
            }

            // Opción 7: calcular todas las estadísticas
            7 -> {

                // Comprobar que existan números
                if (numeros.isEmpty()) {

                    println("No hay datos para calcular estadísticas.")

                } else {

                    // Obtener media
                    val media = calcularMedia(numeros)

                    // Obtener moda
                    val modas = calcularModa(numeros)

                    // Obtener desviación típica
                    val desviacion = calcularDesviacionTipica(numeros)

                    // Mostrar resultados
                    println("\n===== RESULTADOS =====")
                    println("Media: $media")

                    // Mostrar moda o modas
                    if (modas.isEmpty()) {

                        println("No existe moda.")

                    } else if (modas.size == 1) {

                        println("Moda: ${modas[0]}")

                    } else {

                        println("Modas: ${modas.joinToString(", ")}")
                    }

                    // Mostrar desviación típica
                    println("Desviación típica: $desviacion")
                }
            }

            // Opción 8: salir
            0 -> println("Programa finalizado.")

            // Cualquier otra opción
            else -> println("Opción no válida.")
        }

        // El bucle continúa mientras no se seleccione la opción 8
    } while (opcion != 0)
}

// Función para mostrar todos los números almacenados
fun mostrarNumeros(numeros: List<Int>) {

    // Título
    println("Números almacenados:")

    // Mostrar los números separados por comas
    println(numeros.joinToString(", "))
}

// Función que calcula la media
fun calcularMedia(numeros: List<Int>): Double {

    // Suma todos los números y divide entre la cantidad
    return numeros.sum().toDouble() / numeros.size
}

// Función que calcula la moda
fun calcularModa(numeros: List<Int>): List<Int> {

    // Cuenta cuántas veces aparece cada número
    val frecuencias = numeros.groupingBy { it }.eachCount()

    // Obtiene la frecuencia más alta
    val frecuenciaMaxima = frecuencias.values.maxOrNull() ?: 0

    // Si todos aparecen una vez no existe moda
    if (frecuenciaMaxima <= 1) {
        return emptyList()
    }

    // Devuelve todos los números que tengan la frecuencia máxima
    return frecuencias
        .filter { it.value == frecuenciaMaxima }
        .keys
        .sorted()
}

// Función que calcula la desviación típica
fun calcularDesviacionTipica(numeros: List<Int>): Double {

    // Obtener la media
    val media = calcularMedia(numeros)

    // Calcular la suma de las diferencias al cuadrado
    val sumaCuadrados = numeros.sumOf {

        // Diferencia entre el número y la media
        val diferencia = it - media

        // Diferencia elevada al cuadrado
        diferencia * diferencia
    }

    // Calcular la varianza
    val varianza = sumaCuadrados / numeros.size

    // Calcular y devolver la raíz cuadrada de la varianza
    return sqrt(varianza)
}